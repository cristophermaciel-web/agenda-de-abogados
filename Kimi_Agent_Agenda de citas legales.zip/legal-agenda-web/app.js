// LegalAgenda - Sistema de Citas para Abogados
// JavaScript Principal

// ==================== DATOS ====================

const users = [
  { id: '1', email: 'admin@bufete.com', name: 'Administrador', role: 'admin', phone: '' },
  { id: '2', email: 'secretaria@bufete.com', name: 'María González', role: 'secretary', phone: '+52 55 9999 0000' },
  { id: '3', email: 'carlos.martinez@bufete.com', name: 'Dr. Carlos Martínez', role: 'lawyer', phone: '+52 55 1234 5678', specialization: 'Derecho Civil' }
];

const lawyers = [
  { id: '1', name: 'Dr. Carlos Martínez', email: 'carlos.martinez@bufete.com', phone: '+52 55 1234 5678', specialization: 'Derecho Civil', color: '#1e3a5f' },
  { id: '2', name: 'Dra. Ana Rodríguez', email: 'ana.rodriguez@bufete.com', phone: '+52 55 8765 4321', specialization: 'Derecho Familiar', color: '#2c5282' },
  { id: '3', name: 'Dr. Miguel Hernández', email: 'miguel.hernandez@bufete.com', phone: '+52 55 2345 6789', specialization: 'Derecho Mercantil', color: '#c9a227' }
];

let appointments = [
  { id: '1', clientName: 'Juan Pérez García', clientEmail: 'juan.perez@email.com', clientPhone: '+52 55 1111 2222', date: new Date().toISOString().split('T')[0], startTime: '10:00', endTime: '11:00', lawyerId: '1', lawyerName: 'Dr. Carlos Martínez', type: 'Consulta Civil', notes: 'Revisión de contrato de arrendamiento', status: 'booked' },
  { id: '2', clientName: 'María López Sánchez', clientEmail: 'maria.lopez@email.com', clientPhone: '+52 55 3333 4444', date: new Date().toISOString().split('T')[0], startTime: '14:00', endTime: '15:00', lawyerId: '2', lawyerName: 'Dra. Ana Rodríguez', type: 'Divorcio', notes: 'Primera consulta para proceso de divorcio', status: 'booked' },
  { id: '3', clientName: 'Roberto Silva Torres', clientEmail: 'roberto.silva@email.com', clientPhone: '+52 55 5555 6666', date: getFutureDate(2), startTime: '11:00', endTime: '12:00', lawyerId: '1', lawyerName: 'Dr. Carlos Martínez', type: 'Demanda Civil', notes: '', status: 'pending' }
];

const documents = [
  { id: '1', name: 'Contrato_Arrendamiento_JuanPerez.pdf', type: 'application/pdf', size: 2457600, uploadedAt: '2024-03-20', uploadedBy: 'Dr. Carlos Martínez' },
  { id: '2', name: 'Demanda_Civil_2024.docx', type: 'application/docx', size: 512000, uploadedAt: '2024-03-21', uploadedBy: 'Dra. Ana Rodríguez' },
  { id: '3', name: 'Evidencia_Fotografica_Caso.jpg', type: 'image/jpeg', size: 3145728, uploadedAt: '2024-03-22', uploadedBy: 'Secretaria' }
];

// ==================== ESTADO ====================

let currentUser = null;
let currentDate = new Date();
let selectedDate = new Date();
let selectedLawyerFilter = 'all';
let currentPage = 'dashboard';
let selectedDayForAppointment = null;

// ==================== UTILIDADES ====================

function getFutureDate(days) {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date.toISOString().split('T')[0];
}

function formatDate(date) {
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  return date.toLocaleDateString('es-ES', options);
}

function formatTime(time) {
  return time;
}

function getMonthName(month) {
  const months = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
  return months[month];
}

function getDayName(day) {
  const days = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  return days[day];
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function getFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// ==================== TOAST NOTIFICATIONS ====================

function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      ${type === 'success' 
        ? '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22,4 12,14.01 9,11.01"/>'
        : '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>'
      }
    </svg>
    <span>${message}</span>
  `;
  container.appendChild(toast);
  
  setTimeout(() => {
    toast.remove();
  }, 3000);
}

// ==================== LOGIN ====================

function togglePassword() {
  const input = document.getElementById('login-password');
  input.type = input.type === 'password' ? 'text' : 'password';
}

document.getElementById('login-form')?.addEventListener('submit', function(e) {
  e.preventDefault();
  
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;
  const errorDiv = document.getElementById('login-error');
  const spinner = document.getElementById('login-spinner');
  const loginText = document.getElementById('login-text');
  
  spinner.classList.remove('hidden');
  loginText.classList.add('hidden');
  errorDiv.classList.add('hidden');
  
  setTimeout(() => {
    const user = users.find(u => u.email === email);
    
    if (user && password === 'password') {
      currentUser = user;
      localStorage.setItem('currentUser', JSON.stringify(user));
      showApp();
    } else {
      errorDiv.classList.remove('hidden');
      spinner.classList.add('hidden');
      loginText.classList.remove('hidden');
    }
  }, 500);
});

function logout() {
  currentUser = null;
  localStorage.removeItem('currentUser');
  showLogin();
}

function showLogin() {
  document.getElementById('login-screen').classList.remove('hidden');
  document.getElementById('app-screen').classList.add('hidden');
}

function showApp() {
  document.getElementById('login-screen').classList.add('hidden');
  document.getElementById('app-screen').classList.remove('hidden');
  
  // Update user info
  if (currentUser) {
    document.getElementById('user-name').textContent = currentUser.name;
    document.getElementById('user-role').textContent = 
      currentUser.role === 'admin' ? 'Administrador' : 
      currentUser.role === 'secretary' ? 'Secretaria' : 'Abogado';
    document.getElementById('user-avatar').textContent = currentUser.name.charAt(0).toUpperCase();
  }
  
  initApp();
}

// ==================== NAVEGACIÓN ====================

function navigateTo(page) {
  currentPage = page;
  
  // Update nav items
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.toggle('active', item.dataset.page === page);
  });
  
  // Update page title
  const titles = {
    dashboard: 'Calendario Principal',
    secretary: 'Vista Secretaria',
    lawyers: 'Abogados',
    documents: 'Documentos',
    settings: 'Configuración'
  };
  document.getElementById('page-title').textContent = titles[page];
  
  // Show/hide pages
  document.querySelectorAll('.page').forEach(p => {
    p.classList.add('hidden');
  });
  document.getElementById(`page-${page}`).classList.remove('hidden');
  
  // Close sidebar on mobile
  if (window.innerWidth < 1024) {
    document.getElementById('sidebar').classList.remove('open');
  }
  
  // Initialize page
  if (page === 'dashboard') renderCalendar();
  if (page === 'secretary') renderSecretaryView();
  if (page === 'lawyers') renderLawyers();
  if (page === 'documents') renderDocuments();
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

function toggleUserMenu() {
  document.getElementById('user-dropdown').classList.toggle('hidden');
}

// ==================== CALENDARIO ====================

function renderCalendar() {
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  
  document.getElementById('calendar-month').textContent = `${getMonthName(month)} ${year}`;
  
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrevMonth = new Date(year, month, 0).getDate();
  
  const calendarDays = document.getElementById('calendar-days');
  calendarDays.innerHTML = '';
  
  // Previous month days
  for (let i = firstDay - 1; i >= 0; i--) {
    const day = daysInPrevMonth - i;
    const dayEl = createDayElement(day, true);
    calendarDays.appendChild(dayEl);
  }
  
  // Current month days
  for (let day = 1; day <= daysInMonth; day++) {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const dayAppointments = getAppointmentsForDate(dateStr);
    const dayEl = createDayElement(day, false, dateStr, dayAppointments);
    calendarDays.appendChild(dayEl);
  }
  
  // Next month days
  const remainingCells = 42 - (firstDay + daysInMonth);
  for (let day = 1; day <= remainingCells; day++) {
    const dayEl = createDayElement(day, true);
    calendarDays.appendChild(dayEl);
  }
}

function createDayElement(day, isOtherMonth, dateStr = null, dayAppointments = []) {
  const div = document.createElement('div');
  div.className = 'calendar-day';
  
  if (isOtherMonth) {
    div.classList.add('other-month');
  } else {
    const today = new Date().toISOString().split('T')[0];
    if (dateStr === today) div.classList.add('today');
    
    const status = getDayStatus(dayAppointments);
    div.classList.add(status);
    
    div.onclick = () => openDayModal(dateStr);
  }
  
  const header = document.createElement('div');
  header.className = 'day-header';
  
  const dayNum = document.createElement('span');
  dayNum.className = 'day-number';
  if (!isOtherMonth && dateStr === new Date().toISOString().split('T')[0]) {
    dayNum.classList.add('today');
  }
  dayNum.textContent = day;
  header.appendChild(dayNum);
  
  if (dayAppointments.length > 0) {
    const count = document.createElement('span');
    count.className = 'day-appointments-count';
    count.textContent = `${dayAppointments.length} cita${dayAppointments.length > 1 ? 's' : ''}`;
    header.appendChild(count);
  }
  
  div.appendChild(header);
  
  // Show appointments
  dayAppointments.slice(0, 3).forEach(apt => {
    const aptEl = document.createElement('div');
    aptEl.className = `day-appointment ${apt.status}`;
    aptEl.textContent = `${apt.startTime} - ${apt.clientName.split(' ')[0]}`;
    div.appendChild(aptEl);
  });
  
  if (dayAppointments.length > 3) {
    const more = document.createElement('div');
    more.className = 'day-appointments-count';
    more.textContent = `+${dayAppointments.length - 3} más`;
    div.appendChild(more);
  }
  
  return div;
}

function getAppointmentsForDate(dateStr) {
  return appointments.filter(apt => {
    if (selectedLawyerFilter !== 'all' && apt.lawyerId !== selectedLawyerFilter) return false;
    return apt.date === dateStr;
  });
}

function getDayStatus(dayAppointments) {
  if (dayAppointments.length === 0) return 'available';
  const hasBooked = dayAppointments.some(a => a.status === 'booked');
  const hasPending = dayAppointments.some(a => a.status === 'pending');
  if (hasBooked && hasPending) return 'mixed';
  if (hasBooked) return 'booked';
  return 'pending';
}

function prevMonth() {
  currentDate.setMonth(currentDate.getMonth() - 1);
  renderCalendar();
}

function nextMonth() {
  currentDate.setMonth(currentDate.getMonth() + 1);
  renderCalendar();
}

function goToToday() {
  currentDate = new Date();
  renderCalendar();
}

function filterByLawyer() {
  selectedLawyerFilter = document.getElementById('lawyer-filter').value;
  renderCalendar();
}

// ==================== VISTA SECRETARIA ====================

function renderSecretaryView() {
  const dateStr = selectedDate.toISOString().split('T')[0];
  const isToday = dateStr === new Date().toISOString().split('T')[0];
  
  document.getElementById('day-title').textContent = isToday ? 'Hoy' : getDayName(selectedDate.getDay());
  document.getElementById('day-date').textContent = formatDate(selectedDate);
  
  // Update stats
  const dayAppointments = getAppointmentsForDate(dateStr);
  document.getElementById('stat-confirmed').textContent = dayAppointments.filter(a => a.status === 'booked').length;
  document.getElementById('stat-pending').textContent = dayAppointments.filter(a => a.status === 'pending').length;
  document.getElementById('stat-total').textContent = dayAppointments.length;
  
  // Render time slots
  const slotsGrid = document.getElementById('time-slots-grid');
  slotsGrid.innerHTML = '';
  
  const workingHours = [
    '08:00', '08:30', '09:00', '09:30', '10:00', '10:30',
    '11:00', '11:30', '12:00', '12:30', '13:00', '13:30',
    '14:00', '14:30', '15:00', '15:30', '16:00', '16:30',
    '17:00', '17:30', '18:00', '18:30', '19:00'
  ];
  
  workingHours.forEach(time => {
    const apt = dayAppointments.find(a => a.startTime <= time && a.endTime > time);
    const slot = document.createElement('div');
    slot.className = `time-slot ${apt ? apt.status : 'available'}`;
    
    slot.innerHTML = `
      <div class="time-slot-time">${time}</div>
      ${apt 
        ? `<span class="time-slot-status ${apt.status}">${apt.clientName.split(' ')[0]}</span>`
        : '<span class="time-slot-status available">Disponible</span>'
      }
    `;
    
    slot.onclick = () => {
      if (!apt) {
        openAppointmentModalWithTime(time);
      } else {
        openAppointmentModal(null, apt.id);
      }
    };
    
    slotsGrid.appendChild(slot);
  });
}

function prevDay() {
  selectedDate.setDate(selectedDate.getDate() - 1);
  renderSecretaryView();
}

function nextDay() {
  selectedDate.setDate(selectedDate.getDate() + 1);
  renderSecretaryView();
}

function goToTodayDay() {
  selectedDate = new Date();
  renderSecretaryView();
}

function filterSecretaryByLawyer() {
  selectedLawyerFilter = document.getElementById('secretary-lawyer-filter').value;
  renderSecretaryView();
}

function searchAppointments() {
  renderSecretaryView();
}

// ==================== ABOGADOS ====================

function renderLawyers() {
  const searchTerm = document.getElementById('search-lawyers')?.value?.toLowerCase() || '';
  const filtered = lawyers.filter(l => 
    l.name.toLowerCase().includes(searchTerm) ||
    l.specialization.toLowerCase().includes(searchTerm) ||
    l.email.toLowerCase().includes(searchTerm)
  );
  
  const grid = document.getElementById('lawyers-grid');
  grid.innerHTML = '';
  
  filtered.forEach(lawyer => {
    const card = document.createElement('div');
    card.className = 'lawyer-card';
    card.innerHTML = `
      <div class="lawyer-header">
        <div class="lawyer-info">
          <div class="lawyer-avatar" style="background: ${lawyer.color}">
            ${lawyer.name.charAt(0)}
          </div>
          <div>
            <div class="lawyer-name">${lawyer.name}</div>
            <div class="lawyer-specialty">${lawyer.specialization}</div>
          </div>
        </div>
        <div class="lawyer-actions">
          <button class="btn-icon" onclick="editLawyer('${lawyer.id}')">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
            </svg>
          </button>
          <button class="btn-icon" onclick="deleteLawyer('${lawyer.id}')">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3,6 5,6 21,6"/>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
            </svg>
          </button>
        </div>
      </div>
      <div class="lawyer-contact">
        <div class="lawyer-contact-item">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
            <polyline points="22,6 12,13 2,6"/>
          </svg>
          ${lawyer.email}
        </div>
        <div class="lawyer-contact-item">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
          </svg>
          ${lawyer.phone}
        </div>
      </div>
    `;
    grid.appendChild(card);
  });
}

function searchLawyers() {
  renderLawyers();
}

function openLawyerModal() {
  document.getElementById('lawyer-modal').classList.remove('hidden');
  document.getElementById('lawyer-modal-title').textContent = 'Nuevo Abogado';
  document.getElementById('lawyer-form').reset();
  document.getElementById('lawyer-id').value = '';
  document.getElementById('save-lawyer-text').textContent = 'Agregar Abogado';
}

function closeLawyerModal() {
  document.getElementById('lawyer-modal').classList.add('hidden');
}

function editLawyer(id) {
  const lawyer = lawyers.find(l => l.id === id);
  if (!lawyer) return;
  
  document.getElementById('lawyer-modal').classList.remove('hidden');
  document.getElementById('lawyer-modal-title').textContent = 'Editar Abogado';
  document.getElementById('lawyer-id').value = lawyer.id;
  document.getElementById('lawyer-name').value = lawyer.name;
  document.getElementById('lawyer-email').value = lawyer.email;
  document.getElementById('lawyer-phone').value = lawyer.phone;
  document.getElementById('lawyer-specialization').value = lawyer.specialization;
  document.getElementById('save-lawyer-text').textContent = 'Guardar Cambios';
}

function saveLawyer(e) {
  e.preventDefault();
  
  const id = document.getElementById('lawyer-id').value;
  const lawyerData = {
    id: id || generateId(),
    name: document.getElementById('lawyer-name').value,
    email: document.getElementById('lawyer-email').value,
    phone: document.getElementById('lawyer-phone').value,
    specialization: document.getElementById('lawyer-specialization').value,
    color: id ? lawyers.find(l => l.id === id)?.color : `#${Math.floor(Math.random()*16777215).toString(16)}`
  };
  
  if (id) {
    const index = lawyers.findIndex(l => l.id === id);
    lawyers[index] = lawyerData;
    showToast('Abogado actualizado exitosamente');
  } else {
    lawyers.push(lawyerData);
    showToast('Abogado agregado exitosamente');
  }
  
  closeLawyerModal();
  renderLawyers();
  populateLawyerSelects();
}

function deleteLawyer(id) {
  if (!confirm('¿Está seguro de eliminar este abogado?')) return;
  
  const index = lawyers.findIndex(l => l.id === id);
  lawyers.splice(index, 1);
  showToast('Abogado eliminado exitosamente');
  renderLawyers();
  populateLawyerSelects();
}

// ==================== DOCUMENTOS ====================

function renderDocuments() {
  const searchTerm = document.getElementById('search-documents')?.value?.toLowerCase() || '';
  const filter = document.querySelector('.filter-tab.active')?.dataset.filter || 'all';
  
  const filtered = documents.filter(doc => {
    if (!doc.name.toLowerCase().includes(searchTerm)) return false;
    if (filter === 'all') return true;
    if (filter === 'pdf') return doc.type.includes('pdf');
    if (filter === 'image') return doc.type.includes('image');
    if (filter === 'doc') return doc.type.includes('doc') || doc.type.includes('word');
    return true;
  });
  
  const list = document.getElementById('documents-list');
  list.innerHTML = `
    <div class="documents-list-header">
      <div>Nombre</div>
      <div>Tamaño</div>
      <div>Subido por</div>
      <div>Fecha</div>
      <div></div>
    </div>
  `;
  
  filtered.forEach(doc => {
    let iconClass = 'doc';
    if (doc.type.includes('pdf')) iconClass = 'pdf';
    else if (doc.type.includes('image')) iconClass = 'image';
    
    const item = document.createElement('div');
    item.className = 'document-item';
    item.innerHTML = `
      <div class="document-info">
        <div class="document-icon ${iconClass}">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            ${doc.type.includes('pdf') 
              ? '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14,2 14,8 20,8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10,9 9,9 8,9"/>'
              : doc.type.includes('image')
                ? '<rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21,15 16,10 5,21"/>'
                : '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14,2 14,8 20,8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10,9 9,9 8,9"/>'
            }
          </svg>
        </div>
        <div>
          <div class="document-name">${doc.name}</div>
          <div class="document-type">${doc.type.split('/')[1]?.toUpperCase() || 'ARCHIVO'}</div>
        </div>
      </div>
      <div>${getFileSize(doc.size)}</div>
      <div>${doc.uploadedBy}</div>
      <div>${doc.uploadedAt}</div>
      <button class="btn-icon" onclick="deleteDocument('${doc.id}')">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="3,6 5,6 21,6"/>
          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
        </svg>
      </button>
    `;
    list.appendChild(item);
  });
}

function searchDocuments() {
  renderDocuments();
}

function openUploadModal() {
  document.getElementById('upload-modal').classList.remove('hidden');
}

function closeUploadModal() {
  document.getElementById('upload-modal').classList.add('hidden');
}

function handleFileUpload(e) {
  const files = e.target.files;
  if (!files.length) return;
  
  Array.from(files).forEach(file => {
    documents.push({
      id: generateId(),
      name: file.name,
      type: file.type,
      size: file.size,
      uploadedAt: new Date().toISOString().split('T')[0],
      uploadedBy: currentUser?.name || 'Usuario'
    });
  });
  
  showToast(`${files.length} archivo(s) subido(s) exitosamente`);
  closeUploadModal();
  renderDocuments();
}

function deleteDocument(id) {
  if (!confirm('¿Está seguro de eliminar este documento?')) return;
  
  const index = documents.findIndex(d => d.id === id);
  documents.splice(index, 1);
  showToast('Documento eliminado exitosamente');
  renderDocuments();
}

function connectGoogleDrive() {
  showToast('Conectado a Google Drive exitosamente', 'info');
}

// Filter tabs
document.querySelectorAll('.filter-tab').forEach(tab => {
  tab.addEventListener('click', function() {
    document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
    this.classList.add('active');
    renderDocuments();
  });
});

// ==================== CITAS MODAL ====================

function openAppointmentModal(date = null, appointmentId = null) {
  selectedDayForAppointment = date;
  
  const modal = document.getElementById('appointment-modal');
  modal.classList.remove('hidden');
  
  if (appointmentId) {
    const apt = appointments.find(a => a.id === appointmentId);
    if (!apt) return;
    
    document.getElementById('modal-title').textContent = 'Editar Cita';
    document.getElementById('appointment-id').value = apt.id;
    document.getElementById('client-name').value = apt.clientName;
    document.getElementById('client-email').value = apt.clientEmail;
    document.getElementById('client-phone').value = apt.clientPhone;
    document.getElementById('appointment-type').value = apt.type;
    document.getElementById('appointment-date').value = apt.date;
    document.getElementById('appointment-lawyer').value = apt.lawyerId;
    document.getElementById('appointment-start').value = apt.startTime;
    document.getElementById('appointment-end').value = apt.endTime;
    document.getElementById('appointment-notes').value = apt.notes || '';
    document.getElementById('save-btn-text').textContent = 'Guardar Cambios';
  } else {
    document.getElementById('modal-title').textContent = 'Nueva Cita';
    document.getElementById('appointment-form').reset();
    document.getElementById('appointment-id').value = '';
    document.getElementById('appointment-date').value = date || new Date().toISOString().split('T')[0];
    document.getElementById('save-btn-text').textContent = 'Agendar Cita';
  }
}

function openAppointmentModalWithDate() {
  openAppointmentModal(selectedDate.toISOString().split('T')[0]);
}

function openAppointmentModalWithTime(time) {
  openAppointmentModal(selectedDate.toISOString().split('T')[0]);
  document.getElementById('appointment-start').value = time;
  
  // Calculate end time (1 hour later)
  const [hours, minutes] = time.split(':');
  const endHour = parseInt(hours) + 1;
  document.getElementById('appointment-end').value = `${String(endHour).padStart(2, '0')}:${minutes}`;
}

function closeAppointmentModal() {
  document.getElementById('appointment-modal').classList.add('hidden');
}

function saveAppointment(e) {
  e.preventDefault();
  
  const id = document.getElementById('appointment-id').value;
  const lawyerId = document.getElementById('appointment-lawyer').value;
  const lawyer = lawyers.find(l => l.id === lawyerId);
  
  const appointmentData = {
    id: id || generateId(),
    clientName: document.getElementById('client-name').value,
    clientEmail: document.getElementById('client-email').value,
    clientPhone: document.getElementById('client-phone').value,
    type: document.getElementById('appointment-type').value,
    date: document.getElementById('appointment-date').value,
    lawyerId: lawyerId,
    lawyerName: lawyer?.name || '',
    startTime: document.getElementById('appointment-start').value,
    endTime: document.getElementById('appointment-end').value,
    notes: document.getElementById('appointment-notes').value,
    status: id ? appointments.find(a => a.id === id)?.status || 'pending' : 'pending'
  };
  
  if (id) {
    const index = appointments.findIndex(a => a.id === id);
    appointments[index] = appointmentData;
    showToast('Cita actualizada exitosamente');
  } else {
    appointments.push(appointmentData);
    showToast('Cita agendada exitosamente');
  }
  
  closeAppointmentModal();
  
  if (currentPage === 'dashboard') renderCalendar();
  if (currentPage === 'secretary') renderSecretaryView();
}

function deleteAppointment(id) {
  if (!confirm('¿Está seguro de eliminar esta cita?')) return;
  
  const index = appointments.findIndex(a => a.id === id);
  appointments.splice(index, 1);
  showToast('Cita eliminada exitosamente');
  
  closeDayModal();
  if (currentPage === 'dashboard') renderCalendar();
  if (currentPage === 'secretary') renderSecretaryView();
}

function confirmAppointment(id) {
  const apt = appointments.find(a => a.id === id);
  if (apt) {
    apt.status = 'booked';
    showToast('Cita confirmada exitosamente');
    if (currentPage === 'dashboard') renderCalendar();
    if (currentPage === 'secretary') renderSecretaryView();
  }
}

function cancelAppointment(id) {
  const apt = appointments.find(a => a.id === id);
  if (apt) {
    apt.status = 'cancelled';
    showToast('Cita cancelada exitosamente');
    if (currentPage === 'dashboard') renderCalendar();
    if (currentPage === 'secretary') renderSecretaryView();
  }
}

// ==================== DAY MODAL ====================

function openDayModal(dateStr) {
  selectedDayForAppointment = dateStr;
  const dayAppointments = getAppointmentsForDate(dateStr);
  
  const date = new Date(dateStr);
  document.getElementById('day-modal-title').textContent = `Citas del ${formatDate(date)}`;
  
  const container = document.getElementById('day-appointments');
  container.innerHTML = '';
  
  if (dayAppointments.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; padding: 48px; color: var(--gray-500);">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin: 0 auto 16px; color: var(--gray-300);">
          <circle cx="12" cy="12" r="10"/>
          <polyline points="12,6 12,12 16,14"/>
        </svg>
        <p>No hay citas programadas para este día</p>
      </div>
    `;
  } else {
    dayAppointments.forEach(apt => {
      const item = document.createElement('div');
      item.className = 'day-appointment-item';
      item.innerHTML = `
        <div class="day-appointment-time">
          <div class="time">${apt.startTime}</div>
          <div class="duration">${apt.startTime} - ${apt.endTime}</div>
        </div>
        <div class="day-appointment-content">
          <div class="day-appointment-header">
            <span class="status-badge ${apt.status}">
              ${apt.status === 'booked' ? 'Confirmada' : apt.status === 'pending' ? 'Pendiente' : 'Cancelada'}
            </span>
          </div>
          <h4>${apt.clientName}</h4>
          <p>${apt.type}</p>
          <div class="day-appointment-meta">
            <span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                <circle cx="12" cy="7" r="4"/>
              </svg>
              ${apt.lawyerName}
            </span>
            ${apt.clientPhone ? `
              <span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                </svg>
                ${apt.clientPhone}
              </span>
            ` : ''}
          </div>
          ${apt.notes ? `<p style="margin-top: 8px; padding: 8px; background: var(--gray-50); border-radius: 6px; font-size: 13px;">${apt.notes}</p>` : ''}
        </div>
        <div class="day-appointment-actions">
          ${apt.status === 'pending' ? `
            <button class="btn-icon" onclick="confirmAppointment('${apt.id}')" title="Confirmar">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="20,6 9,17 4,12"/>
              </svg>
            </button>
          ` : ''}
          <button class="btn-icon" onclick="openAppointmentModal(null, '${apt.id}')" title="Editar">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
            </svg>
          </button>
          <button class="btn-icon" onclick="deleteAppointment('${apt.id}')" title="Eliminar">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3,6 5,6 21,6"/>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
            </svg>
          </button>
        </div>
      `;
      container.appendChild(item);
    });
  }
  
  document.getElementById('day-modal').classList.remove('hidden');
}

function closeDayModal() {
  document.getElementById('day-modal').classList.add('hidden');
}

function addAppointmentFromDay() {
  closeDayModal();
  openAppointmentModal(selectedDayForAppointment);
}

// ==================== INTEGRACIONES ====================

function toggleGoogleCalendar() {
  const btn = document.getElementById('btn-google-calendar');
  const info = document.getElementById('google-calendar-info');
  btn.classList.toggle('active');
  info.classList.toggle('hidden');
}

function toggleGoogleDrive() {
  const btn = document.getElementById('btn-google-drive');
  const info = document.getElementById('google-drive-info');
  btn.classList.toggle('active');
  info.classList.toggle('hidden');
}

function toggleIntegration(btn) {
  btn.classList.toggle('connected');
  btn.textContent = btn.classList.contains('connected') ? 'Conectado' : 'Conectar';
}

// ==================== CONFIGURACIÓN ====================

function saveProfile() {
  showToast('Perfil actualizado exitosamente');
}

function saveNotifications() {
  showToast('Preferencias guardadas exitosamente');
}

function changePassword() {
  showToast('Contraseña actualizada exitosamente');
}

// Settings tabs
document.querySelectorAll('.settings-tab').forEach(tab => {
  tab.addEventListener('click', function() {
    const tabId = this.dataset.tab;
    
    document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
    this.classList.add('active');
    
    document.querySelectorAll('.settings-panel').forEach(p => p.classList.add('hidden'));
    document.getElementById(`tab-${tabId}`).classList.remove('hidden');
  });
});

// ==================== INICIALIZACIÓN ====================

function populateLawyerSelects() {
  const selects = ['lawyer-filter', 'secretary-lawyer-filter', 'appointment-lawyer'];
  
  selects.forEach(selectId => {
    const select = document.getElementById(selectId);
    if (!select) return;
    
    const currentValue = select.value;
    
    // Keep first option
    const firstOption = select.options[0];
    select.innerHTML = '';
    select.appendChild(firstOption);
    
    lawyers.forEach(lawyer => {
      const option = document.createElement('option');
      option.value = lawyer.id;
      option.textContent = `${lawyer.name} - ${lawyer.specialization}`;
      select.appendChild(option);
    });
    
    select.value = currentValue;
  });
}

function initApp() {
  // Nav items
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => navigateTo(item.dataset.page));
  });
  
  populateLawyerSelects();
  renderCalendar();
  renderLawyers();
  renderDocuments();
}

// Check for saved session
const savedUser = localStorage.getItem('currentUser');
if (savedUser) {
  currentUser = JSON.parse(savedUser);
  showApp();
}

// Close dropdowns on click outside
document.addEventListener('click', function(e) {
  if (!e.target.closest('.user-menu')) {
    document.getElementById('user-dropdown')?.classList.add('hidden');
  }
});
