import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, Appointment, Lawyer } from '@/types';

interface AppState {
  currentUser: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  
  users: User[];
  lawyers: Lawyer[];
  appointments: Appointment[];
  
  addAppointment: (appointment: Appointment) => void;
  updateAppointment: (id: string, updates: Partial<Appointment>) => void;
  deleteAppointment: (id: string) => void;
  
  addLawyer: (lawyer: Lawyer) => void;
  updateLawyer: (id: string, updates: Partial<Lawyer>) => void;
  deleteLawyer: (id: string) => void;
  
  selectedLawyer: string | 'all';
  setSelectedLawyer: (lawyerId: string | 'all') => void;
}

const sampleLawyers: Lawyer[] = [
  {
    id: '1',
    name: 'Dr. Carlos Martínez',
    email: 'carlos.martinez@bufete.com',
    phone: '+52 55 1234 5678',
    specialization: 'Derecho Civil',
    color: '#1e3a5f'
  },
  {
    id: '2',
    name: 'Dra. Ana Rodríguez',
    email: 'ana.rodriguez@bufete.com',
    phone: '+52 55 8765 4321',
    specialization: 'Derecho Familiar',
    color: '#2c5282'
  },
  {
    id: '3',
    name: 'Dr. Miguel Hernández',
    email: 'miguel.hernandez@bufete.com',
    phone: '+52 55 2345 6789',
    specialization: 'Derecho Mercantil',
    color: '#c9a227'
  }
];

const sampleAppointments: Appointment[] = [
  {
    id: '1',
    clientName: 'Juan Pérez García',
    clientEmail: 'juan.perez@email.com',
    clientPhone: '+52 55 1111 2222',
    date: new Date(),
    startTime: '10:00',
    endTime: '11:00',
    lawyerId: '1',
    lawyerName: 'Dr. Carlos Martínez',
    type: 'Consulta Civil',
    notes: 'Revisión de contrato de arrendamiento',
    status: 'booked',
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: '2',
    clientName: 'María López Sánchez',
    clientEmail: 'maria.lopez@email.com',
    clientPhone: '+52 55 3333 4444',
    date: new Date(),
    startTime: '14:00',
    endTime: '15:00',
    lawyerId: '2',
    lawyerName: 'Dra. Ana Rodríguez',
    type: 'Divorcio',
    notes: 'Primera consulta para proceso de divorcio',
    status: 'booked',
    createdAt: new Date(),
    updatedAt: new Date()
  }
];

const sampleUsers: User[] = [
  {
    id: '1',
    email: 'admin@bufete.com',
    name: 'Administrador',
    role: 'admin',
    createdAt: new Date()
  },
  {
    id: '2',
    email: 'secretaria@bufete.com',
    name: 'María González',
    role: 'secretary',
    createdAt: new Date()
  },
  {
    id: '3',
    email: 'carlos.martinez@bufete.com',
    name: 'Dr. Carlos Martínez',
    role: 'lawyer',
    specialization: 'Derecho Civil',
    createdAt: new Date()
  }
];

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      isAuthenticated: false,
      
      login: async (email: string, password: string) => {
        const user = sampleUsers.find(u => u.email === email);
        if (user && password === 'password') {
          set({ currentUser: user, isAuthenticated: true });
          return true;
        }
        return false;
      },
      
      logout: () => {
        set({ currentUser: null, isAuthenticated: false });
      },
      
      users: sampleUsers,
      lawyers: sampleLawyers,
      appointments: sampleAppointments,
      
      addAppointment: (appointment) => set(state => ({
        appointments: [...state.appointments, appointment]
      })),
      
      updateAppointment: (id, updates) => set(state => ({
        appointments: state.appointments.map(a => 
          a.id === id ? { ...a, ...updates, updatedAt: new Date() } : a
        )
      })),
      
      deleteAppointment: (id) => set(state => ({
        appointments: state.appointments.filter(a => a.id !== id)
      })),
      
      addLawyer: (lawyer) => set(state => ({ 
        lawyers: [...state.lawyers, lawyer] 
      })),
      
      updateLawyer: (id, updates) => set(state => ({
        lawyers: state.lawyers.map(l => l.id === id ? { ...l, ...updates } : l)
      })),
      
      deleteLawyer: (id) => set(state => ({
        lawyers: state.lawyers.filter(l => l.id !== id)
      })),
      
      selectedLawyer: 'all',
      setSelectedLawyer: (lawyerId) => set({ selectedLawyer: lawyerId })
    }),
    {
      name: 'legal-agenda-storage'
    }
  )
);
