export type UserRole = 'admin' | 'secretary' | 'lawyer';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  avatar?: string;
  phone?: string;
  specialization?: string;
  createdAt: Date;
}

export type AppointmentStatus = 'available' | 'booked' | 'pending' | 'cancelled' | 'completed';

export interface Appointment {
  id: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  date: Date;
  startTime: string;
  endTime: string;
  lawyerId: string;
  lawyerName: string;
  type: string;
  notes?: string;
  status: AppointmentStatus;
  createdAt: Date;
  updatedAt: Date;
}

export interface Lawyer {
  id: string;
  name: string;
  email: string;
  phone: string;
  specialization: string;
  avatar?: string;
  color: string;
}

export interface Document {
  id: string;
  name: string;
  url: string;
  type: string;
  size: number;
  uploadedAt: Date;
  uploadedBy: string;
}

export type ViewType = 'month' | 'week' | 'day';
