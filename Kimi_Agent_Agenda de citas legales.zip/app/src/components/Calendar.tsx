import { useState, useMemo } from 'react';
import { useStore } from '@/store/useStore';
import { 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  Clock, 
  User, 
  Phone, 
  Mail,
  FileText,
  MoreVertical,
  Filter
} from 'lucide-react';
import { 
  format, 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  addDays, 
  isSameMonth, 
  isSameDay, 
  addMonths, 
  subMonths,
  isToday
} from 'date-fns';
import { es } from 'date-fns/locale';
import type { Appointment } from '@/types';

interface CalendarProps {
  onNewAppointment: (date?: Date) => void;
  onEditAppointment: (appointment: Appointment) => void;
}

export function Calendar({ onNewAppointment, onEditAppointment }: CalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [showDayDetails, setShowDayDetails] = useState(false);
  
  const appointments = useStore(state => state.appointments);
  const lawyers = useStore(state => state.lawyers);
  const selectedLawyer = useStore(state => state.selectedLawyer);
  const setSelectedLawyer = useStore(state => state.setSelectedLawyer);
  const deleteAppointment = useStore(state => state.deleteAppointment);
  
  const weekDays = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
  const monthNames = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ];
  
  const filteredAppointments = useMemo(() => {
    if (selectedLawyer === 'all') return appointments;
    return appointments.filter(a => a.lawyerId === selectedLawyer);
  }, [appointments, selectedLawyer]);
  
  const getAppointmentsForDate = (date: Date) => {
    return filteredAppointments.filter(a => {
      const aDate = new Date(a.date);
      return isSameDay(aDate, date);
    });
  };
  
  const getDayStatus = (date: Date): 'available' | 'booked' | 'mixed' | 'empty' => {
    const dayAppointments = getAppointmentsForDate(date);
    if (dayAppointments.length === 0) return 'available';
    
    const hasBooked = dayAppointments.some(a => a.status === 'booked');
    const hasPending = dayAppointments.some(a => a.status === 'pending');
    
    if (hasBooked && hasPending) return 'mixed';
    if (hasBooked) return 'booked';
    if (hasPending) return 'pending';
    return 'available';
  };
  
  const generateCalendarDays = () => {
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(monthStart);
    const calendarStart = startOfWeek(monthStart);
    const calendarEnd = endOfWeek(monthEnd);
    
    const days = [];
    let day = calendarStart;
    
    while (day <= calendarEnd) {
      days.push(day);
      day = addDays(day, 1);
    }
    
    return days;
  };
  
  const handlePrevMonth = () => setCurrentDate(subMonths(currentDate, 1));
  const handleNextMonth = () => setCurrentDate(addMonths(currentDate, 1));
  const handleToday = () => setCurrentDate(new Date());
  
  const handleDayClick = (date: Date) => {
    setSelectedDate(date);
    setShowDayDetails(true);
  };
  
  const handleDelete = (id: string) => {
    if (confirm('¿Está seguro de eliminar esta cita?')) {
      deleteAppointment(id);
    }
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'booked': return 'bg-red-500';
      case 'pending': return 'bg-orange-500';
      case 'completed': return 'bg-green-500';
      case 'cancelled': return 'bg-gray-400';
      default: return 'bg-blue-500';
    }
  };
  
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'booked': return 'Confirmada';
      case 'pending': return 'Pendiente';
      case 'completed': return 'Completada';
      case 'cancelled': return 'Cancelada';
      default: return 'Desconocido';
    }
  };
  
  const calendarDays = generateCalendarDays();
  
  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-4">
          <button onClick={handlePrevMonth} className="p-2 hover:bg-gray-100 rounded-lg">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <h2 className="text-2xl font-bold text-legal-primary font-serif">
            {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
          </h2>
          <button onClick={handleNextMonth} className="p-2 hover:bg-gray-100 rounded-lg">
            <ChevronRight className="w-5 h-5" />
          </button>
          <button onClick={handleToday} className="px-4 py-2 text-sm font-medium text-legal-primary hover:bg-legal-primary/10 rounded-lg">
            Hoy
          </button>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-gray-500" />
            <select
              value={selectedLawyer}
              onChange={(e) => setSelectedLawyer(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-legal-primary"
            >
              <option value="all">Todos los abogados</option>
              {lawyers.map(lawyer => (
                <option key={lawyer.id} value={lawyer.id}>{lawyer.name}</option>
              ))}
            </select>
          </div>
          
          <button
            onClick={() => onNewAppointment()}
            className="flex items-center gap-2 px-4 py-2 bg-legal-accent hover:bg-yellow-600 text-white rounded-lg transition-colors font-medium"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Nueva Cita</span>
          </button>
        </div>
      </div>
      
      {/* Legend */}
      <div className="flex flex-wrap items-center gap-4 mb-4 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-green-500"></div>
          <span className="text-gray-600">Disponible</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-red-500"></div>
          <span className="text-gray-600">Agendado</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-orange-500"></div>
          <span className="text-gray-600">Pendiente</span>
        </div>
      </div>
      
      {/* Calendar Grid */}
      <div className="flex-1 bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="grid grid-cols-7 border-b border-gray-200">
          {weekDays.map(day => (
            <div key={day} className="py-3 text-center text-sm font-semibold text-gray-600 bg-gray-50">
              {day}
            </div>
          ))}
        </div>
        
        <div className="grid grid-cols-7 flex-1">
          {calendarDays.map((day, index) => {
            const isCurrentMonth = isSameMonth(day, currentDate);
            const isTodayDate = isToday(day);
            const dayStatus = getDayStatus(day);
            const dayAppointments = getAppointmentsForDate(day);
            
            let dayClass = 'min-h-[100px] p-2 border-b border-r border-gray-100 cursor-pointer transition-all ';
            
            if (!isCurrentMonth) {
              dayClass += 'bg-gray-50/50 text-gray-400 ';
            } else if (dayStatus === 'booked') {
              dayClass += 'bg-red-50 hover:bg-red-100 ';
            } else if (dayStatus === 'pending') {
              dayClass += 'bg-orange-50 hover:bg-orange-100 ';
            } else if (dayStatus === 'mixed') {
              dayClass += 'bg-gradient-to-br from-red-50 to-orange-50 ';
            } else {
              dayClass += 'bg-green-50 hover:bg-green-100 ';
            }
            
            if (isTodayDate) {
              dayClass += 'ring-2 ring-inset ring-legal-primary ';
            }
            
            return (
              <div
                key={index}
                onClick={() => handleDayClick(day)}
                className={dayClass}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-medium ${isTodayDate ? 'text-legal-primary' : 'text-gray-700'}`}>
                    {format(day, 'd')}
                  </span>
                  {dayAppointments.length > 0 && (
                    <span className="text-xs text-gray-500">
                      {dayAppointments.length} cita{dayAppointments.length > 1 ? 's' : ''}
                    </span>
                  )}
                </div>
                
                <div className="space-y-1">
                  {dayAppointments.slice(0, 3).map((apt, i) => (
                    <div
                      key={i}
                      className={`text-xs px-2 py-1 rounded truncate ${getStatusColor(apt.status)} text-white`}
                    >
                      {apt.startTime} - {apt.clientName.split(' ')[0]}
                    </div>
                  ))}
                  {dayAppointments.length > 3 && (
                    <div className="text-xs text-gray-500 text-center">
                      +{dayAppointments.length - 3} más
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      
      {/* Day Details Modal */}
      {showDayDetails && selectedDate && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[80vh] overflow-auto">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-xl font-bold text-legal-primary font-serif">
                Citas del {format(selectedDate, 'd \'de\' MMMM, yyyy', { locale: es })}
              </h3>
              <button onClick={() => setShowDayDetails(false)} className="p-2 hover:bg-gray-100 rounded-lg">
                <span className="sr-only">Cerrar</span>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="p-6 space-y-3">
              {getAppointmentsForDate(selectedDate).length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Clock className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p>No hay citas programadas para este día</p>
                  <button
                    onClick={() => {
                      setShowDayDetails(false);
                      onNewAppointment(selectedDate);
                    }}
                    className="mt-4 px-4 py-2 bg-legal-accent text-white rounded-lg hover:bg-yellow-600"
                  >
                    Agregar Cita
                  </button>
                </div>
              ) : (
                getAppointmentsForDate(selectedDate).map(apt => (
                  <div key={apt.id} className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <span className={`px-2 py-1 text-xs font-medium rounded ${getStatusColor(apt.status)} text-white`}>
                            {getStatusLabel(apt.status)}
                          </span>
                          <span className="text-sm text-gray-500 flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {apt.startTime} - {apt.endTime}
                          </span>
                        </div>
                        
                        <h4 className="font-semibold text-gray-900 mb-1">{apt.clientName}</h4>
                        <p className="text-sm text-gray-600 mb-2">{apt.type}</p>
                        
                        <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
                          <span className="flex items-center gap-1">
                            <User className="w-4 h-4" />
                            {apt.lawyerName}
                          </span>
                          {apt.clientPhone && (
                            <span className="flex items-center gap-1">
                              <Phone className="w-4 h-4" />
                              {apt.clientPhone}
                            </span>
                          )}
                        </div>
                        
                        {apt.notes && (
                          <p className="mt-2 text-sm text-gray-600 bg-gray-50 p-2 rounded">
                            <FileText className="w-4 h-4 inline mr-1" />
                            {apt.notes}
                          </p>
                        )}
                      </div>
                      
                      <div className="flex gap-1">
                        <button
                          onClick={() => {
                            setShowDayDetails(false);
                            onEditAppointment(apt);
                          }}
                          className="p-2 hover:bg-gray-100 rounded-lg"
                        >
                          <span className="sr-only">Editar</span>
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                          </svg>
                        </button>
                        <button
                          onClick={() => handleDelete(apt.id)}
                          className="p-2 hover:bg-red-50 text-red-600 rounded-lg"
                        >
                          <span className="sr-only">Eliminar</span>
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
