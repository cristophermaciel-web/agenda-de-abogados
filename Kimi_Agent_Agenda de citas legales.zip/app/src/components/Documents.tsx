import { useState } from 'react';
import { Upload, Search, File, FileText, FileImage, Trash2, Folder, Link, X } from 'lucide-react';
import { format } from 'date-fns';
import { useStore } from '@/store/useStore';
import type { Document } from '@/types';

export function Documents() {
  const documents = useStore(state => state.documents);
  const addDocument = useStore(state => state.addDocument);
  const deleteDocument = useStore(state => state.deleteDocument);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'pdf' | 'image' | 'doc'>('all');
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [showGoogleDriveDialog, setShowGoogleDriveDialog] = useState(false);
  
  const getFileIcon = (type: string) => {
    if (type.includes('pdf')) return <FileText className="w-8 h-8 text-red-500" />;
    if (type.includes('image')) return <FileImage className="w-8 h-8 text-blue-500" />;
    return <File className="w-8 h-8 text-gray-500" />;
  };
  
  const getFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };
  
  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(searchTerm.toLowerCase());
    if (selectedFilter === 'all') return matchesSearch;
    if (selectedFilter === 'pdf') return matchesSearch && doc.type.includes('pdf');
    if (selectedFilter === 'image') return matchesSearch && doc.type.includes('image');
    if (selectedFilter === 'doc') return matchesSearch && (doc.type.includes('doc') || doc.type.includes('word'));
    return matchesSearch;
  });
  
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    
    Array.from(files).forEach(file => {
      const newDoc: Document = {
        id: Date.now().toString() + Math.random().toString(),
        name: file.name,
        url: URL.createObjectURL(file),
        type: file.type,
        size: file.size,
        uploadedAt: new Date(),
        uploadedBy: 'Usuario Actual'
      };
      addDocument(newDoc);
    });
    
    setShowUploadDialog(false);
  };
  
  const handleDelete = (id: string) => {
    if (confirm('¿Está seguro de eliminar este documento?')) {
      deleteDocument(id);
    }
  };
  
  // Sample documents
  const sampleDocs: Document[] = [
    {
      id: '1',
      name: 'Contrato_Arrendamiento.pdf',
      url: '#',
      type: 'application/pdf',
      size: 2457600,
      uploadedAt: new Date('2024-03-20'),
      uploadedBy: 'Dr. Carlos Martínez'
    },
    {
      id: '2',
      name: 'Demanda_Civil.docx',
      url: '#',
      type: 'application/docx',
      size: 512000,
      uploadedAt: new Date('2024-03-21'),
      uploadedBy: 'Dra. Ana Rodríguez'
    }
  ];
  
  const allDocuments = [...sampleDocs, ...filteredDocuments];
  
  return (
    <div className="h-full flex flex-col">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-legal-primary font-serif">Documentos</h2>
          <p className="text-gray-500">Gestione los documentos de sus casos</p>
        </div>
        
        <div className="flex gap-3">
          <button
            onClick={() => setShowGoogleDriveDialog(true)}
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
          >
            <Link className="w-4 h-4" />
            Google Drive
          </button>
          
          <button
            onClick={() => setShowUploadDialog(true)}
            className="flex items-center gap-2 px-4 py-2 bg-legal-accent hover:bg-yellow-600 text-white rounded-lg font-medium"
          >
            <Upload className="w-4 h-4" />
            Subir Archivo
          </button>
        </div>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar documentos..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
          />
        </div>
        
        <div className="flex gap-2">
          {['all', 'pdf', 'image', 'doc'].map(filter => (
            <button
              key={filter}
              onClick={() => setSelectedFilter(filter as any)}
              className={`px-3 py-2 text-sm rounded-lg border transition-all ${
                selectedFilter === filter
                  ? 'bg-legal-primary text-white border-legal-primary'
                  : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
              }`}
            >
              {filter === 'all' ? 'Todos' : filter.toUpperCase()}
            </button>
          ))}
        </div>
      </div>
      
      <div className="flex-1 bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-4 border-b border-gray-200 bg-gray-50">
          <div className="grid grid-cols-12 gap-4 text-sm font-medium text-gray-600">
            <div className="col-span-5">Nombre</div>
            <div className="col-span-2">Tamaño</div>
            <div className="col-span-2">Subido por</div>
            <div className="col-span-2">Fecha</div>
            <div className="col-span-1"></div>
          </div>
        </div>
        
        <div className="divide-y divide-gray-100">
          {allDocuments.map(doc => (
            <div key={doc.id} className="grid grid-cols-12 gap-4 p-4 items-center hover:bg-gray-50">
              <div className="col-span-5 flex items-center gap-3">
                {getFileIcon(doc.type)}
                <div>
                  <p className="font-medium text-gray-900 truncate">{doc.name}</p>
                  <p className="text-xs text-gray-500">{doc.type.split('/')[1]?.toUpperCase()}</p>
                </div>
              </div>
              
              <div className="col-span-2 text-sm text-gray-600">{getFileSize(doc.size)}</div>
              <div className="col-span-2 text-sm text-gray-600">{doc.uploadedBy}</div>
              <div className="col-span-2 text-sm text-gray-600">{format(new Date(doc.uploadedAt), 'dd/MM/yyyy')}</div>
              
              <div className="col-span-1 flex justify-end">
                <button onClick={() => handleDelete(doc.id)} className="p-2 hover:bg-red-50 text-red-600 rounded-lg">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
        
        {allDocuments.length === 0 && (
          <div className="text-center py-12">
            <Folder className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-medium text-gray-900 mb-1">No hay documentos</h3>
            <p className="text-gray-500">Suba archivos o conecte Google Drive</p>
          </div>
        )}
      </div>
      
      {/* Upload Dialog */}
      {showUploadDialog && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-legal-primary font-serif">Subir Documento</h3>
              <button onClick={() => setShowUploadDialog(false)} className="p-2 hover:bg-gray-100 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-legal-primary transition-colors">
              <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
              <p className="text-gray-600 mb-2">Arrastre archivos aquí o haga clic para seleccionar</p>
              <p className="text-sm text-gray-400">PDF, Word, Excel, Imágenes hasta 50MB</p>
              <input
                type="file"
                multiple
                onChange={handleFileUpload}
                className="hidden"
                id="file-upload"
              />
              <label
                htmlFor="file-upload"
                className="inline-block mt-4 px-4 py-2 bg-legal-primary text-white rounded-lg cursor-pointer hover:bg-legal-secondary"
              >
                Seleccionar Archivos
              </label>
            </div>
          </div>
        </div>
      )}
      
      {/* Google Drive Dialog */}
      {showGoogleDriveDialog && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-legal-primary font-serif">Conectar Google Drive</h3>
              <button onClick={() => setShowGoogleDriveDialog(false)} className="p-2 hover:bg-gray-100 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="text-center p-6 bg-blue-50 rounded-lg">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
                <Folder className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Google Drive</h3>
              <p className="text-sm text-gray-600 mb-4">
                Conecte su cuenta de Google Drive para sincronizar documentos automáticamente
              </p>
              <button
                onClick={() => setShowGoogleDriveDialog(false)}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
              >
                <Link className="w-4 h-4" />
                Conectar con Google
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
