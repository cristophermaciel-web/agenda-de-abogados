import { useState, useMemo } from 'react';
import { useStore } from '@/store/useStore';
import { 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  Clock, 
  User, 
  Phone, 
  CheckCircle,
  XCircle,
  AlertCircle,
  Calendar as CalendarIcon,
  Search
} from 'lucide-react';
import { format, addDays, subDays, isToday, isSameDay } from 'date-fns';
import { es } from 'date-fns/locale';
import type { Appointment } from '@/types';

interface SecretaryViewProps {
  onNewAppointment: (date?: Date, time?: string) => void;
  onEditAppointment: (appointment: Appointment) => void;
}

export function SecretaryView({ onNewAppointment, onEditAppointment }: SecretaryViewProps) {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedLawyer, setSelectedLawyer] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAppointmentDetails, setShowAppointmentDetails] = useState<Appointment | null>(null);
  
  const appointments = useStore(state => state.appointments);
  const lawyers = useStore(state => state.lawyers);
  const updateAppointment = useStore(state => state.updateAppointment);
  
  const workingHours = [
    '08:00', '08:30', '09:00', '09:30', '10:00', '10:30',
    '11:00', '11:30', '12:00', '12:30', '13:00', '13:30',
    '14:00', '14:30', '15:00', '15:30', '16:00', '16:30',
    '17:00', '17:30', '18:00', '18:30', '19:00'
  ];
  
  const filteredAppointments = useMemo(() => {
    let filtered = appointments.filter(a => isSameDay(new Date(a.date), selectedDate));
    
    if (selectedLawyer !== 'all') {
      filtered = filtered.filter(a => a.lawyerId === selectedLawyer);
    }
    
    if (searchTerm) {
      filtered = filtered.filter(a => 
        a.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        a.type.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    return filtered.sort((a, b) => a.startTime.localeCompare(b.startTime));
  }, [appointments, selectedDate, selectedLawyer, searchTerm]);
  
  const getTimeSlotStatus = (time: string) => {
    const appointment = filteredAppointments.find(a => a.startTime <= time && a.endTime > time);
    return { available: !appointment, appointment };
  };
  
  const handlePrevDay = () => setSelectedDate(subDays(selectedDate, 1));
  const handleNextDay = () => setSelectedDate(addDays(selectedDate, 1));
  const handleToday = () => setSelectedDate(new Date());
  
  const handleConfirm = (id: string) => {
    updateAppointment(id, { status: 'booked' });
    setShowAppointmentDetails(null);
  };
  
  const handleCancel = (id: string) => {
    updateAppointment(id, { status: 'cancelled' });
    setShowAppointmentDetails(null);
  };
  
  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'booked':
        return { color: 'bg-red-100 text-red-800 border-red-200', icon: <CheckCircle className="w-4 h-4" />, label: 'Confirmada' };
      case 'pending':
        return { color: 'bg-orange-100 text-orange-800 border-orange-200', icon: <AlertCircle className="w-4 h-4" />, label: 'Pendiente' };
      case 'cancelled':
        return { color: 'bg-gray-100 text-gray-600 border-gray-200', icon: <XCircle className="w-4 h-4" />, label: 'Cancelada' };
      case 'completed':
        return { color: 'bg-green-100 text-green-800 border-green-200', icon: <CheckCircle className="w-4 h-4" />, label: 'Completada' };
      default:
        return { color: 'bg-blue-100 text-blue-800 border-blue-200', icon: <Clock className="w-4 h-4" />, label: 'Desconocido' };
    }
  };
  
  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-4">
          <button onClick={handlePrevDay} className="p-2 hover:bg-gray-100 rounded-lg">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="text-center">
            <h2 className="text-2xl font-bold text-legal-primary font-serif">
              {isToday(selectedDate) ? 'Hoy' : format(selectedDate, 'EEEE', { locale: es })}
            </h2>
            <p className="text-gray-500">
              {format(selectedDate, 'd \'de\' MMMM, yyyy', { locale: es })}
            </p>
          </div>
          <button onClick={handleNextDay} className="p-2 hover:bg-gray-100 rounded-lg">
            <ChevronRight className="w-5 h-5" />
          </button>
          <button onClick={handleToday} className="px-4 py-2 text-sm font-medium text-legal-primary hover:bg-legal-primary/10 rounded-lg">
            Hoy
          </button>
        </div>
        
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar cita..."
              className="pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-legal-primary w-full sm:w-48"
            />
          </div>
          
          <select
            value={selectedLawyer}
            onChange={(e) => setSelectedLawyer(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-legal-primary"
          >
            <option value="all">Todos los abogados</option>
            {lawyers.map(lawyer => (
              <option key={lawyer.id} value={lawyer.id}>{lawyer.name}</option>
            ))}
          </select>
          
          <button
            onClick={() => onNewAppointment(selectedDate)}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-legal-accent hover:bg-yellow-600 text-white rounded-lg transition-colors font-medium"
          >
            <Plus className="w-4 h-4" />
            <span>Nueva Cita</span>
          </button>
        </div>
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {filteredAppointments.filter(a => a.status === 'booked').length}
              </p>
              <p className="text-sm text-gray-500">Confirmadas</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {filteredAppointments.filter(a => a.status === 'pending').length}
              </p>
              <p className="text-sm text-gray-500">Pendientes</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Clock className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {workingHours.length - filteredAppointments.length}
              </p>
              <p className="text-sm text-gray-500">Disponibles</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-legal-primary rounded-lg flex items-center justify-center">
              <CalendarIcon className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {filteredAppointments.length}
              </p>
              <p className="text-sm text-gray-500">Total Citas</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Time slots grid */}
      <div className="flex-1 bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-4 border-b border-gray-200 bg-gray-50">
          <h3 className="font-semibold text-gray-700">Horarios del Día</h3>
          <p className="text-sm text-gray-500">Haga clic en un horario para agendar una cita</p>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 p-4">
          {workingHours.map(time => {
            const slot = getTimeSlotStatus(time);
            const status = slot.appointment?.status;
            
            let buttonClass = 'relative p-4 rounded-lg border-2 transition-all ';
            
            if (slot.available) {
              buttonClass += 'border-green-300 bg-green-50 hover:bg-green-100 hover:border-green-400 cursor-pointer';
            } else if (status === 'booked') {
              buttonClass += 'border-red-300 bg-red-50 cursor-pointer';
            } else if (status === 'pending') {
              buttonClass += 'border-orange-300 bg-orange-50 cursor-pointer';
            } else {
              buttonClass += 'border-gray-300 bg-gray-50 cursor-pointer';
            }
            
            return (
              <button
                key={time}
                onClick={() => {
                  if (slot.available) {
                    onNewAppointment(selectedDate, time);
                  } else if (slot.appointment) {
                    setShowAppointmentDetails(slot.appointment);
                  }
                }}
                className={buttonClass}
              >
                <div className="text-center">
                  <span className="font-mono font-semibold text-lg">{time}</span>
                  {slot.appointment && (
                    <div className="mt-2">
                      <span className={`inline-flex items-center gap-1 px-2 py-1 text-xs rounded-full ${
                        status === 'booked' ? 'bg-red-200 text-red-800' :
                        status === 'pending' ? 'bg-orange-200 text-orange-800' :
                        'bg-gray-200 text-gray-800'
                      }`}>
                        {status === 'booked' && <CheckCircle className="w-3 h-3" />}
                        {status === 'pending' && <AlertCircle className="w-3 h-3" />}
                        {slot.appointment.clientName.split(' ')[0]}
                      </span>
                    </div>
                  )}
                  {slot.available && (
                    <div className="mt-2">
                      <span className="inline-flex items-center gap-1 px-2 py-1 text-xs rounded-full bg-green-200 text-green-800">
                        <Plus className="w-3 h-3" />
                        Disponible
                      </span>
                    </div>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>
      
      {/* Appointment Details Modal */}
      {showAppointmentDetails && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-xl font-bold text-legal-primary font-serif">Detalles de la Cita</h3>
              <button onClick={() => setShowAppointmentDetails(null)} className="p-2 hover:bg-gray-100 rounded-lg">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium border ${
                getStatusConfig(showAppointmentDetails.status).color
              }`}>
                {getStatusConfig(showAppointmentDetails.status).icon}
                {getStatusConfig(showAppointmentDetails.status).label}
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500">Horario</p>
                    <p className="font-medium">{showAppointmentDetails.startTime} - {showAppointmentDetails.endTime}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <User className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500">Cliente</p>
                    <p className="font-medium">{showAppointmentDetails.clientName}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <User className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500">Abogado</p>
                    <p className="font-medium">{showAppointmentDetails.lawyerName}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <CalendarIcon className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500">Tipo de Consulta</p>
                    <p className="font-medium">{showAppointmentDetails.type}</p>
                  </div>
                </div>
                
                {showAppointmentDetails.clientPhone && (
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-gray-400" />
                    <div>
                      <p className="text-sm text-gray-500">Teléfono</p>
                      <p className="font-medium">{showAppointmentDetails.clientPhone}</p>
                    </div>
                  </div>
                )}
                
                {showAppointmentDetails.notes && (
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-sm text-gray-500 mb-1">Notas</p>
                    <p className="text-sm">{showAppointmentDetails.notes}</p>
                  </div>
                )}
              </div>
              
              <div className="flex gap-3 pt-4 border-t">
                {showAppointmentDetails.status === 'pending' && (
                  <button
                    onClick={() => handleConfirm(showAppointmentDetails.id)}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg"
                  >
                    <CheckCircle className="w-4 h-4" />
                    Confirmar
                  </button>
                )}
                
                <button
                  onClick={() => {
                    setShowAppointmentDetails(null);
                    onEditAppointment(showAppointmentDetails);
                  }}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-legal-primary hover:bg-legal-secondary text-white rounded-lg"
                >
                  Editar
                </button>
                
                {showAppointmentDetails.status !== 'cancelled' && (
                  <button
                    onClick={() => handleCancel(showAppointmentDetails.id)}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg"
                  >
                    <XCircle className="w-4 h-4" />
                    Cancelar
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
