import { useState } from 'react';
import { useStore } from '@/store/useStore';
import { User, Mail, Phone, Lock, Bell, Calendar, Link, Save, CheckCircle, Shield } from 'lucide-react';

export function Settings() {
  const currentUser = useStore(state => state.currentUser);
  const [activeTab, setActiveTab] = useState<'profile' | 'notifications' | 'integrations' | 'security'>('profile');
  
  const [profileData, setProfileData] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || '',
    phone: currentUser?.phone || ''
  });
  
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    appointmentReminders: true,
    newAppointmentAlerts: true,
    cancelledAppointmentAlerts: true
  });
  
  const [integrationSettings, setIntegrationSettings] = useState({
    googleCalendar: false,
    googleDrive: false,
    outlook: false
  });
  
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  
  const tabs = [
    { id: 'profile', label: 'Perfil', icon: User },
    { id: 'notifications', label: 'Notificaciones', icon: Bell },
    { id: 'integrations', label: 'Integraciones', icon: Link },
    { id: 'security', label: 'Seguridad', icon: Shield }
  ];
  
  return (
    <div className="h-full flex flex-col">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-legal-primary font-serif">Configuración</h2>
        <p className="text-gray-500">Administre su cuenta y preferencias</p>
      </div>
      
      <div className="flex flex-col lg:flex-row gap-6 flex-1">
        {/* Sidebar Tabs */}
        <div className="lg:w-64 flex lg:flex-col gap-2 overflow-x-auto">
          {tabs.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-legal-primary text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
                }`}
              >
                <Icon className="w-5 h-5" />
                {tab.label}
              </button>
            );
          })}
        </div>
        
        {/* Content */}
        <div className="flex-1 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          {activeTab === 'profile' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-1">Información del Perfil</h3>
                <p className="text-gray-500">Actualice su información personal</p>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nombre Completo</label>
                  <input
                    type="text"
                    value={profileData.name}
                    onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Correo Electrónico</label>
                  <input
                    type="email"
                    value={profileData.email}
                    onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Teléfono</label>
                  <input
                    type="tel"
                    value={profileData.phone}
                    onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                    placeholder="+52 55 1234 5678"
                  />
                </div>
              </div>
              
              <div className="pt-4 border-t">
                <button className="flex items-center gap-2 px-4 py-2 bg-legal-accent hover:bg-yellow-600 text-white rounded-lg">
                  <Save className="w-4 h-4" />
                  Guardar Cambios
                </button>
              </div>
            </div>
          )}
          
          {activeTab === 'notifications' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-1">Configuración de Notificaciones</h3>
                <p className="text-gray-500">Elija cómo desea recibir las notificaciones</p>
              </div>
              
              <div className="space-y-4">
                {[
                  { id: 'emailNotifications', label: 'Notificaciones por Email', description: 'Recibir notificaciones en mi correo electrónico' },
                  { id: 'appointmentReminders', label: 'Recordatorios de Citas', description: 'Recordarme las citas programadas' },
                  { id: 'newAppointmentAlerts', label: 'Alertas de Nuevas Citas', description: 'Notificarme cuando se agregue una nueva cita' },
                  { id: 'cancelledAppointmentAlerts', label: 'Alertas de Citas Canceladas', description: 'Notificarme cuando se cancele una cita' }
                ].map(setting => (
                  <div key={setting.id} className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      id={setting.id}
                      checked={notificationSettings[setting.id as keyof typeof notificationSettings]}
                      onChange={(e) => setNotificationSettings({
                        ...notificationSettings,
                        [setting.id]: e.target.checked
                      })}
                      className="mt-1 w-4 h-4 text-legal-primary border-gray-300 rounded focus:ring-legal-primary"
                    />
                    <div>
                      <label htmlFor={setting.id} className="font-medium text-gray-900 cursor-pointer">
                        {setting.label}
                      </label>
                      <p className="text-sm text-gray-500">{setting.description}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="pt-4 border-t">
                <button className="flex items-center gap-2 px-4 py-2 bg-legal-accent hover:bg-yellow-600 text-white rounded-lg">
                  <Save className="w-4 h-4" />
                  Guardar Preferencias
                </button>
              </div>
            </div>
          )}
          
          {activeTab === 'integrations' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-1">Integraciones</h3>
                <p className="text-gray-500">Conecte sus servicios externos</p>
              </div>
              
              <div className="space-y-4">
                {[
                  { id: 'googleCalendar', name: 'Google Calendar', description: 'Sincronice citas con Google Calendar', icon: Calendar, color: 'bg-blue-500' },
                  { id: 'googleDrive', name: 'Google Drive', description: 'Almacene documentos en Google Drive', icon: Link, color: 'bg-green-500' },
                  { id: 'outlook', name: 'Microsoft Outlook', description: 'Sincronice con Outlook Calendar', icon: Mail, color: 'bg-blue-700' }
                ].map(integration => {
                  const Icon = integration.icon;
                  const isConnected = integrationSettings[integration.id as keyof typeof integrationSettings];
                  
                  return (
                    <div key={integration.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 ${integration.color} rounded-lg flex items-center justify-center`}>
                          <Icon className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900">{integration.name}</h4>
                          <p className="text-sm text-gray-500">{integration.description}</p>
                        </div>
                      </div>
                      
                      <button
                        onClick={() => setIntegrationSettings({
                          ...integrationSettings,
                          [integration.id]: !isConnected
                        })}
                        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                          isConnected ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {isConnected && <CheckCircle className="w-4 h-4" />}
                        {isConnected ? 'Conectado' : 'Conectar'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
          
          {activeTab === 'security' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-1">Seguridad</h3>
                <p className="text-gray-500">Actualice su contraseña y configure la seguridad</p>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Contraseña Actual</label>
                  <input
                    type="password"
                    value={passwordData.currentPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                    placeholder="••••••••"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nueva Contraseña</label>
                  <input
                    type="password"
                    value={passwordData.newPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                    placeholder="••••••••"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Confirmar Nueva Contraseña</label>
                  <input
                    type="password"
                    value={passwordData.confirmPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                    placeholder="••••••••"
                  />
                </div>
              </div>
              
              <div className="pt-4 border-t">
                <button className="flex items-center gap-2 px-4 py-2 bg-legal-accent hover:bg-yellow-600 text-white rounded-lg">
                  <Lock className="w-4 h-4" />
                  Cambiar Contraseña
                </button>
              </div>
              
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">Consejos de Seguridad</h4>
                <ul className="text-sm text-blue-800 space-y-1 list-disc list-inside">
                  <li>Use al menos 8 caracteres</li>
                  <li>Incluya números y símbolos</li>
                  <li>No reutilice contraseñas de otros sitios</li>
                  <li>Cambie su contraseña periódicamente</li>
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
