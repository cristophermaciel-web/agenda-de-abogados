import { useState, useEffect } from 'react';
import { useStore } from '@/store/useStore';
import { Calendar, Clock, User, Mail, Phone, FileText, Save, Upload, Link } from 'lucide-react';
import { format, addMinutes, parse } from 'date-fns';
import type { Appointment } from '@/types';

interface AppointmentFormProps {
  isOpen: boolean;
  onClose: () => void;
  appointment?: Appointment | null;
  defaultDate?: Date;
  defaultTime?: string;
}

export function AppointmentForm({ 
  isOpen, 
  onClose, 
  appointment, 
  defaultDate,
  defaultTime 
}: AppointmentFormProps) {
  const lawyers = useStore(state => state.lawyers);
  const addAppointment = useStore(state => state.addAppointment);
  const updateAppointment = useStore(state => state.updateAppointment);
  
  const [formData, setFormData] = useState({
    clientName: '',
    clientEmail: '',
    clientPhone: '',
    date: defaultDate ? format(defaultDate, 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd'),
    startTime: defaultTime || '09:00',
    endTime: defaultTime ? format(addMinutes(parse(defaultTime, 'HH:mm', new Date()), 60), 'HH:mm') : '10:00',
    lawyerId: '',
    type: '',
    notes: '',
    status: 'pending' as const
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showGoogleCalendar, setShowGoogleCalendar] = useState(false);
  const [showGoogleDrive, setShowGoogleDrive] = useState(false);
  
  const consultationTypes = [
    'Consulta Civil', 'Consulta Familiar', 'Consulta Mercantil', 'Consulta Laboral',
    'Consulta Penal', 'Divorcio', 'Testamento', 'Contrato', 'Demanda', 'Mediación', 'Otro'
  ];
  
  useEffect(() => {
    if (appointment) {
      setFormData({
        clientName: appointment.clientName,
        clientEmail: appointment.clientEmail,
        clientPhone: appointment.clientPhone,
        date: format(new Date(appointment.date), 'yyyy-MM-dd'),
        startTime: appointment.startTime,
        endTime: appointment.endTime,
        lawyerId: appointment.lawyerId,
        type: appointment.type,
        notes: appointment.notes || '',
        status: appointment.status
      });
    } else {
      setFormData({
        clientName: '',
        clientEmail: '',
        clientPhone: '',
        date: defaultDate ? format(defaultDate, 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd'),
        startTime: defaultTime || '09:00',
        endTime: defaultTime ? format(addMinutes(parse(defaultTime, 'HH:mm', new Date()), 60), 'HH:mm') : '10:00',
        lawyerId: lawyers[0]?.id || '',
        type: '',
        notes: '',
        status: 'pending'
      });
    }
  }, [appointment, defaultDate, defaultTime, lawyers, isOpen]);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const selectedLawyer = lawyers.find(l => l.id === formData.lawyerId);
    
    const appointmentData: Appointment = {
      id: appointment?.id || Date.now().toString(),
      clientName: formData.clientName,
      clientEmail: formData.clientEmail,
      clientPhone: formData.clientPhone,
      date: new Date(formData.date),
      startTime: formData.startTime,
      endTime: formData.endTime,
      lawyerId: formData.lawyerId,
      lawyerName: selectedLawyer?.name || '',
      type: formData.type,
      notes: formData.notes,
      status: formData.status,
      createdAt: appointment?.createdAt || new Date(),
      updatedAt: new Date()
    };
    
    if (appointment) {
      updateAppointment(appointment.id, appointmentData);
    } else {
      addAppointment(appointmentData);
    }
    
    setIsSubmitting(false);
    onClose();
  };
  
  const generateTimeOptions = () => {
    const times = [];
    for (let hour = 8; hour <= 19; hour++) {
      times.push(`${hour.toString().padStart(2, '0')}:00`);
      times.push(`${hour.toString().padStart(2, '0')}:30`);
    }
    return times;
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-auto">
        <div className="p-6 border-b border-gray-200 flex items-center justify-between">
          <h3 className="text-xl font-bold text-legal-primary font-serif">
            {appointment ? 'Editar Cita' : 'Nueva Cita'}
          </h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Client Information */}
          <div className="bg-gray-50 p-4 rounded-lg space-y-4">
            <h4 className="font-semibold text-gray-700 flex items-center gap-2">
              <User className="w-4 h-4" />
              Información del Cliente
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nombre Completo *</label>
                <input
                  type="text"
                  value={formData.clientName}
                  onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                  placeholder="Juan Pérez García"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Correo Electrónico *</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="email"
                    value={formData.clientEmail}
                    onChange={(e) => setFormData({ ...formData, clientEmail: e.target.value })}
                    className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                    placeholder="cliente@email.com"
                    required
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Teléfono</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="tel"
                    value={formData.clientPhone}
                    onChange={(e) => setFormData({ ...formData, clientPhone: e.target.value })}
                    className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                    placeholder="+52 55 1234 5678"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tipo de Consulta *</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                  required
                >
                  <option value="">Seleccionar tipo</option>
                  {consultationTypes.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>
          
          {/* Appointment Details */}
          <div className="bg-gray-50 p-4 rounded-lg space-y-4">
            <h4 className="font-semibold text-gray-700 flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Detalles de la Cita
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Fecha *</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Abogado *</label>
                <select
                  value={formData.lawyerId}
                  onChange={(e) => setFormData({ ...formData, lawyerId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                  required
                >
                  <option value="">Seleccionar abogado</option>
                  {lawyers.map(lawyer => (
                    <option key={lawyer.id} value={lawyer.id}>
                      {lawyer.name} - {lawyer.specialization}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Hora de Inicio *</label>
                <select
                  value={formData.startTime}
                  onChange={(e) => {
                    setFormData({ ...formData, startTime: e.target.value });
                    const start = parse(e.target.value, 'HH:mm', new Date());
                    const end = addMinutes(start, 60);
                    setFormData(prev => ({ ...prev, endTime: format(end, 'HH:mm') }));
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                  required
                >
                  {generateTimeOptions().map(time => (
                    <option key={time} value={time}>{time}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Hora de Fin *</label>
                <select
                  value={formData.endTime}
                  onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                  required
                >
                  {generateTimeOptions().map(time => (
                    <option key={time} value={time}>{time}</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Notas Adicionales</label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary resize-none"
                rows={3}
                placeholder="Información adicional sobre la cita..."
              />
            </div>
          </div>
          
          {/* Integrations */}
          <div className="bg-gray-50 p-4 rounded-lg space-y-4">
            <h4 className="font-semibold text-gray-700 flex items-center gap-2">
              <Link className="w-4 h-4" />
              Integraciones
            </h4>
            
            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => setShowGoogleCalendar(!showGoogleCalendar)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-all ${
                  showGoogleCalendar ? 'bg-blue-50 border-blue-300 text-blue-700' : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                }`}
              >
                <Calendar className="w-4 h-4" />
                Google Calendar
              </button>
              
              <button
                type="button"
                onClick={() => setShowGoogleDrive(!showGoogleDrive)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-all ${
                  showGoogleDrive ? 'bg-green-50 border-green-300 text-green-700' : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                }`}
              >
                <Upload className="w-4 h-4" />
                Google Drive
              </button>
            </div>
            
            {showGoogleCalendar && (
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                <p className="text-sm text-blue-800">
                  <strong>Google Calendar:</strong> La cita se sincronizará automáticamente con el calendario del abogado seleccionado.
                </p>
              </div>
            )}
            
            {showGoogleDrive && (
              <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                <p className="text-sm text-green-800 mb-2">
                  <strong>Google Drive:</strong> Se creará una carpeta para los documentos del cliente.
                </p>
                <button
                  type="button"
                  className="flex items-center gap-2 px-3 py-1.5 bg-white text-green-700 text-sm rounded border border-green-300 hover:bg-green-50"
                >
                  <Upload className="w-4 h-4" />
                  Subir Documentos
                </button>
              </div>
            )}
          </div>
          
          {/* Actions */}
          <div className="flex gap-3 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
            >
              Cancelar
            </button>
            
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-legal-accent hover:bg-yellow-600 text-white rounded-lg disabled:opacity-50"
            >
              {isSubmitting ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  {appointment ? 'Guardar Cambios' : 'Agendar Cita'}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
