import { useState } from 'react';
import { useStore } from '@/store/useStore';
import { Plus, Search, Edit2, Trash2, Mail, Phone, Briefcase, User, X, Save } from 'lucide-react';
import type { Lawyer } from '@/types';

export function LawyersManagement() {
  const lawyers = useStore(state => state.lawyers);
  const addLawyer = useStore(state => state.addLawyer);
  const updateLawyer = useStore(state => state.updateLawyer);
  const deleteLawyer = useStore(state => state.deleteLawyer);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingLawyer, setEditingLawyer] = useState<Lawyer | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    specialization: ''
  });
  
  const specializations = [
    'Derecho Civil', 'Derecho Familiar', 'Derecho Mercantil', 'Derecho Laboral',
    'Derecho Penal', 'Derecho Constitucional', 'Derecho Administrativo',
    'Derecho Internacional', 'Propiedad Intelectual', 'Derecho Fiscal'
  ];
  
  const filteredLawyers = lawyers.filter(lawyer =>
    lawyer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    lawyer.specialization.toLowerCase().includes(searchTerm.toLowerCase()) ||
    lawyer.email.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const lawyerData: Lawyer = {
      id: editingLawyer?.id || Date.now().toString(),
      name: formData.name,
      email: formData.email,
      phone: formData.phone,
      specialization: formData.specialization,
      color: editingLawyer?.color || `#${Math.floor(Math.random()*16777215).toString(16)}`
    };
    
    if (editingLawyer) {
      updateLawyer(editingLawyer.id, lawyerData);
    } else {
      addLawyer(lawyerData);
    }
    
    setShowForm(false);
    setEditingLawyer(null);
    resetForm();
  };
  
  const handleEdit = (lawyer: Lawyer) => {
    setEditingLawyer(lawyer);
    setFormData({
      name: lawyer.name,
      email: lawyer.email,
      phone: lawyer.phone,
      specialization: lawyer.specialization
    });
    setShowForm(true);
  };
  
  const handleDelete = (id: string) => {
    if (confirm('¿Está seguro de eliminar este abogado?')) {
      deleteLawyer(id);
    }
  };
  
  const resetForm = () => {
    setFormData({ name: '', email: '', phone: '', specialization: '' });
  };
  
  return (
    <div className="h-full flex flex-col">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-legal-primary font-serif">Gestión de Abogados</h2>
          <p className="text-gray-500">Administre los abogados del bufete</p>
        </div>
        
        <button
          onClick={() => {
            setEditingLawyer(null);
            resetForm();
            setShowForm(true);
          }}
          className="flex items-center justify-center gap-2 px-4 py-2 bg-legal-accent hover:bg-yellow-600 text-white rounded-lg font-medium"
        >
          <Plus className="w-4 h-4" />
          Nuevo Abogado
        </button>
      </div>
      
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Buscar abogado por nombre, especialidad o correo..."
          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredLawyers.map(lawyer => (
          <div key={lawyer.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div 
                  className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg"
                  style={{ backgroundColor: lawyer.color }}
                >
                  {lawyer.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{lawyer.name}</h3>
                  <p className="text-sm text-gray-500">{lawyer.specialization}</p>
                </div>
              </div>
              
              <div className="flex gap-1">
                <button onClick={() => handleEdit(lawyer)} className="p-2 hover:bg-gray-100 rounded-lg">
                  <Edit2 className="w-4 h-4 text-gray-600" />
                </button>
                <button onClick={() => handleDelete(lawyer.id)} className="p-2 hover:bg-red-50 rounded-lg">
                  <Trash2 className="w-4 h-4 text-red-600" />
                </button>
              </div>
            </div>
            
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-gray-600">
                <Mail className="w-4 h-4" />
                {lawyer.email}
              </div>
              <div className="flex items-center gap-2 text-gray-600">
                <Phone className="w-4 h-4" />
                {lawyer.phone}
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {filteredLawyers.length === 0 && (
        <div className="text-center py-12">
          <User className="w-16 h-16 mx-auto mb-4 text-gray-300" />
          <h3 className="text-lg font-medium text-gray-900 mb-1">No se encontraron abogados</h3>
          <p className="text-gray-500">Intente con otra búsqueda o agregue un nuevo abogado</p>
        </div>
      )}
      
      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-xl font-bold text-legal-primary font-serif">
                {editingLawyer ? 'Editar Abogado' : 'Nuevo Abogado'}
              </h3>
              <button onClick={() => setShowForm(false)} className="p-2 hover:bg-gray-100 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nombre Completo *</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                    placeholder="Dr. Juan Pérez"
                    required
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Correo Electrónico *</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                    placeholder="abogado@bufete.com"
                    required
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Teléfono *</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                    placeholder="+52 55 1234 5678"
                    required
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Especialización *</label>
                <div className="relative">
                  <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <select
                    value={formData.specialization}
                    onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                    className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-legal-primary"
                    required
                  >
                    <option value="">Seleccionar especialización</option>
                    {specializations.map(spec => (
                      <option key={spec} value={spec}>{spec}</option>
                    ))}
                  </select>
                </div>
              </div>
              
              <div className="flex gap-3 pt-4 border-t">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Cancelar
                </button>
                
                <button
                  type="submit"
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-legal-accent hover:bg-yellow-600 text-white rounded-lg"
                >
                  <Save className="w-4 h-4" />
                  {editingLawyer ? 'Guardar Cambios' : 'Agregar Abogado'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
