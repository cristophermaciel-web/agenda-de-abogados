import { useState } from 'react';
import { useStore } from '@/store/useStore';
import { Login } from '@/components/Login';
import { Layout } from '@/components/Layout';
import { Calendar } from '@/components/Calendar';
import { SecretaryView } from '@/components/SecretaryView';
import { LawyersManagement } from '@/components/LawyersManagement';
import { Documents } from '@/components/Documents';
import { Settings } from '@/components/Settings';
import { AppointmentForm } from '@/components/AppointmentForm';
import type { Appointment } from '@/types';

function App() {
  const isAuthenticated = useStore(state => state.isAuthenticated);
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [showAppointmentForm, setShowAppointmentForm] = useState(false);
  const [editingAppointment, setEditingAppointment] = useState<Appointment | null>(null);
  const [defaultDate, setDefaultDate] = useState<Date | undefined>(undefined);
  const [defaultTime, setDefaultTime] = useState<string | undefined>(undefined);
  
  const handleNewAppointment = (date?: Date, time?: string) => {
    setEditingAppointment(null);
    setDefaultDate(date);
    setDefaultTime(time);
    setShowAppointmentForm(true);
  };
  
  const handleEditAppointment = (appointment: Appointment) => {
    setEditingAppointment(appointment);
    setDefaultDate(undefined);
    setDefaultTime(undefined);
    setShowAppointmentForm(true);
  };
  
  const handleCloseAppointmentForm = () => {
    setShowAppointmentForm(false);
    setEditingAppointment(null);
    setDefaultDate(undefined);
    setDefaultTime(undefined);
  };
  
  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return (
          <Calendar 
            onNewAppointment={handleNewAppointment}
            onEditAppointment={handleEditAppointment}
          />
        );
      case 'secretary':
        return (
          <SecretaryView 
            onNewAppointment={handleNewAppointment}
            onEditAppointment={handleEditAppointment}
          />
        );
      case 'lawyers':
        return <LawyersManagement />;
      case 'documents':
        return <Documents />;
      case 'settings':
        return <Settings />;
      default:
        return (
          <Calendar 
            onNewAppointment={handleNewAppointment}
            onEditAppointment={handleEditAppointment}
          />
        );
    }
  };
  
  if (!isAuthenticated) {
    return <Login />;
  }
  
  return (
    <>
      <Layout currentPage={currentPage} onPageChange={setCurrentPage}>
        {renderPage()}
      </Layout>
      
      <AppointmentForm
        isOpen={showAppointmentForm}
        onClose={handleCloseAppointmentForm}
        appointment={editingAppointment}
        defaultDate={defaultDate}
        defaultTime={defaultTime}
      />
    </>
  );
}

export default App;
